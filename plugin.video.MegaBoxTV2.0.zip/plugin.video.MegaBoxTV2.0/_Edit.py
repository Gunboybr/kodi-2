import xbmcaddon
MainBase = 'https://gist.githubusercontent.com/Gunboybr/e2e17544d3603fce8b020de63487c6e8/raw/basemega'
addon = xbmcaddon.Addon('plugin.video.MegaBoxTV2.0')